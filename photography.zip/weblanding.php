<?php
include "system.config.php";
?>
<html>
	<head>
		<meta http-equiv='content-type' content='text/html; charset=UTF-8'/>
		<meta name='author' content='ARVIX Studio'/>
		<meta name='keywords' content='ARVIX Studio,ARVIX,photo,photography' /> 
		<meta name='viewport' content='width=device-width,maximum-scale=1.0,initial-scale=1.0,user-scalable=no'/>
		<meta name='format-detection' content='telephone=no'/>
		<title><?php echo $webinfo[title]; ?></title>
		<link rel="shortcut ico" href="">
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
		<link rel="stylesheet" href="morphext.css">
		<link rel="stylesheet" href="rotator.css">
		<link rel="stylesheet" href="imgslide.css">
		<script src="js/jquery.3.1.1.min.js"></script>
<style type="text/css">
.preloader {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 9999;
  background-color: #000a1e;
}
.preloader .loading {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%,-50%);
  font: 14px arial;
}
</style>

	</head>
<body>
<script>
$(document).ready(function(){
$(".preloader").fadeOut();
})
</script>
<div class="preloader">
  <div class="loading">
    <img src="img/loading.gif" width="200">
  </div>
</div>
</body>	
<?php
$lokasi = $_GET['location'];
if(!$lokasi){
	header("location:landing?location=home/");
}else
if($lokasi == "home/"){
	include "webhome.php";
}else
if($lokasi == "home/galery/"){
	include "image.display.php";
}else
if($lokasi == "adminarea/"){
	include "adminsc/index.php";
}else
if($lokasi == "adminarea/authentication/"){
	include "adminsc/login.php";
}else{
	header("location:landing?location=home/");
}
?>
