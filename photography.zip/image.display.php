	<?php
	$katid = $_GET['katid'];
	if(!$katid){
		echo '';
	}else
	if(!preg_match("/^[0-9]*$/",$katid)){
		header("location:./");
	}else{
		$kuerikat = mysql_query("SELECT * FROM kategorigambar WHERE id='$katid'");
		if(mysql_num_rows($kuerikat) == '0'){
			header("location:./");
		}else{
			$katdata = mysql_fetch_array($kuerikat);
		}
	?>
<div class='tampilpic' id="myDIV">
	<center>
		<a onclick="myFunction()"><i class="far fa-minus-square" style="font-size:50px"></i></a>
	<button class="w3-button w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
<button class="w3-button w3-display-right" onclick="plusDivs(+1)">&#10095;</button>

	<img class='mySlides' src='img/demo/<?php echo "$katdata[imgcover]"; ?>' width='350px'><br/>
	<?php
	$queriys=mysql_query("SELECT * FROM galeri WHERE kategori='$katid'");
	while($subimg=mysql_fetch_array($queriys)){
		echo "<img class='mySlides' src='img/demo/$subimg[urlfoto]' width='350px'>";
	}
	?>
	</center>
	<br/>
	<b><?php echo "$katdata[name]"; ?></b><br/><br/>
	<?php echo "$katdata[komntar]"; ?>
	<?php
	}
	?>
	<script>
	var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
    showDivs(slideIndex += n);
}

function showDivs(n) {
    var i;
    var x = document.getElementsByClassName("mySlides");
    if (n > x.length) {slideIndex = 1} 
    if (n < 1) {slideIndex = x.length} ;
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none"; 
    }
    x[slideIndex-1].style.display = "block"; 
}
</script>
</div>
<script>
function myFunction() {
    var x = document.getElementById('myDIV');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}
</script>
