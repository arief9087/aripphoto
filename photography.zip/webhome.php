	<?php
	$katid = $_GET['katid'];
	if(!$katid){
		echo '';
	}else
	if(!preg_match("/^[0-9]*$/",$katid)){
		header("location:./");
	}else{
		$kuerikat = mysql_query("SELECT * FROM kategorigambar WHERE id='$katid'");
		if(mysql_num_rows($kuerikat) == '0'){
			header("location:./");
		}else{
			$katdata = mysql_fetch_array($kuerikat);
		}
	?>
<div class='tampilpic' id="myDIV">
	<center>
		<a onclick="myFunction()"><i class="far fa-minus-square" style="font-size:50px"></i></a>
	<button class="w3-button w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
<button class="w3-button w3-display-right" onclick="plusDivs(+1)">&#10095;</button>

	<img class='mySlides' src='img/demo/<?php echo "$katdata[imgcover]"; ?>' width='350px'><br/>
	<?php
	$queriys=mysql_query("SELECT * FROM galeri WHERE kategori='$katid'");
	while($subimg=mysql_fetch_array($queriys)){
		echo "<img class='mySlides' src='img/demo/$subimg[urlfoto]' width='350px'>";
	}
	?>
	</center>
	<br/>
	<b><?php echo "$katdata[name]"; ?></b><br/><br/>
	<?php echo "$katdata[komntar]"; ?>
	<?php
	}
	?>
	<script>
	var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
    showDivs(slideIndex += n);
}

function showDivs(n) {
    var i;
    var x = document.getElementsByClassName("mySlides");
    if (n > x.length) {slideIndex = 1} 
    if (n < 1) {slideIndex = x.length} ;
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none"; 
    }
    x[slideIndex-1].style.display = "block"; 
}
</script>
<br/><br/><br/><br/><br/><br/>
<br/><br/><br/><br/><br/><br/>
<br/><br/><br/><br/><br/><br/>
<br/><br/><br/><br/><br/><br/>
</div>
<script>
function myFunction() {
    var x = document.getElementById('myDIV');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else {
        x.style.display = 'none';
    }
}
</script>
<div class='indexhead'>
		<div class='menu'><i class="fas fa-map-marker"></i> Klik Disini</div>
		<div class='menu'><i class="fas fa-phone"></i> <?php echo $webinfo[nomorhp]; ?></div>
	<div class='text'>
		<img src='img/arvix.png'>
		<div class='title'><?php echo $webinfo[webname]; ?></div>
		<div class='desc'>
			<span id='js-rotating'><?php echo $webinfo[rotator]; ?></span>
		</div >
        <script>window.jQuery || document.write('<script src="bower_components/jquery/jquery.min.js"><\/script>')</script>
        <script src="js/morphext.js"></script>
        <script>
            $("#js-rotating").Morphext({
                animation: "<?php echo $webinfo[rotatortype]; ?>",
                complete: function () {
                    console.log("This is called after a phrase is animated in! Current phrase index: " + this.index);
                }
            });
        </script>
        </div>
        <br/><br/><br/><br/><br/><br/><br/>
	</div>
</div>
<div class='ourmission'>
	<br/>
	<h1>Job History</h1>
	<br/>
</div>
<div class='display'>
	<br/>
<?php
if(empty($_GET[start])){
$st = "0";
}else{
$st = $_GET[start];
} 
$tampil = $st*12;
$que=mysql_query("SELECT * FROM kategorigambar ORDER BY nourut ASC LIMIT $tampil,12");
while($row=mysql_fetch_array($que)){
	echo "<a href='landing?location=home/&start=$st&katid=$row[id]'><div class='img'><img src='img/demo/$row[imgcover]' name='$webinfo[webname]' title='$webinfo[webname]'></div></a>";
}
$que2=mysql_query("SELECT * FROM galeri");
$num=mysql_num_rows($que2);
$hal = ceil($num/12);
echo "<br/><br/><br/><br/><br/>" ;
for($i=1;$i<=$hal;$i++){
$page=$i-1; 
echo " [ <a href='landing?location=home/&start=$page'>$i</a> ] ";
} 
?>
<br/><br/>
</div>
<div class='footer'>
	<br/><br/><br/>
<b><font style='font-size:19px;'><i class="fas fa-building"></i> Alamat Kantor</font></b><br/><br/>
<?php echo $webinfo[office]; ?><br/><br/><br/>
<b><font style='font-size:19px;'><i class="fas fa-comments"></i> SMS Center</font></b><br/><br/>
<b><?php echo $webinfo[webname]; ?></b> - <?php echo $webinfo[nomorhp]; ?><br/><br/><br/>
<a href='https://api.whatsapp.com/send?text=Permisi, Saya Mau Tau Info Tentang *<?php echo $webinfo[webname]; ?>*&phone=<?php
$nomorhape = $webinfo[nomorhp]; 
$ubahnomor = substr($nomorhape,1);
echo "62$ubahnomor";
?>'><button>Chat Whatsapp</button></a>
<br/><br/><br/>
<a href='<?php echo $webinfo[facebook]; ?>' style='color:white'><i class="fab fa-facebook" style="font-size:20px"></i></a>
<a href='<?php echo $webinfo[instagram]; ?>' style='color:white'><i class="fab fa-instagram" style="font-size:20px"></i></a>
<a href='https://api.whatsapp.com/send?text=Permisi, Saya Mau Tau Info Tentang *<?php echo $webinfo[webname]; ?>*&phone=<?php
$nomorhape = $webinfo[nomorhp]; 
$ubahnomor = substr($nomorhape,1);
echo "62$ubahnomor";
?>' style='color:white'><i class="fab fa-whatsapp" style="font-size:20px"></i></a>
<a href='<?php echo $webinfo[youtube]; ?>' style='color:white'><i class="fab fa-youtube" style="font-size:20px"></i></a>
<br/><br/>
<font size='2'>&copy; <?php echo date("Y");?> <?php echo $webinfo[webname]; ?>, Hak Cipta Dilindungi Undang Undang.<br/>Powerd by AlexaMP Production</font>
<br/><br/>
</div>

<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="js/jquery.backstretch.min.js"></script>
<script type="text/javascript">
	$.backstretch(
	[
		"img/background/1.jpg",
		"img/background/3.jpg",
		"img/background/2.jpg"
	], 
	{
		duration: 1200, 
		fade: 600
	});
</script>
