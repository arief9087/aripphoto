<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
$weburl = $_POST["url"];
$title = $_POST["title"];
$nomorhp = $_POST["nomorhp"];
$maps = $_POST["maps"];
$office = $_POST["office"];
$facebook = $_POST["facebook"];
$instagram = $_POST["instagram"];
$youtube = $_POST["youtube"];
$textrotate = $_POST["rotator"];
$webname = $_POST["webname"];
$rotatortype = $_POST["rotatortype"];
if(!$_POST['submit']){
	echo "";
}else{
	$update = mysql_query("UPDATE site SET url='$weburl',title='$title',nomorhp='$nomorhp',maps='$maps',office='$office',facebook='$facebook',instagram='$instagram',youtube='$youtube',rotator='$textrotate',webname='$webname',rotatortype='$rotatortype' WHERE id='1'");
	if($update){
		echo "<script>swal('Berhasil!', 'Data Berhasil Diperbarui!', 'success');</script>";
	}else{
		echo "<script>swal('Kesalahan!', 'Gagal Memperbarui Informasi!', 'error');</script>";
	}
}
?>



<?php
$ambildata = mysql_query("SELECT * FROM site WHERE id='1'");
$webdata = mysql_fetch_array($ambildata);
?>
<form method='post' action=''>
Web Url
<input type='text' name='url' value='<?php echo $webdata[url]; ?>' class='textadd'>
Judul Website
<input type='text' name='title' value='<?php echo $webdata[title]; ?>' class='textadd'>
Nama Website/Nama Usaha
<input type='text' name='webname' value='<?php echo $webdata[webname]; ?>' class='textadd'>
Text Rotator (Gunakan koma Sebagai Pemisah Perkalimat)
<input type='text' name='rotator' value='<?php echo $webdata[rotator]; ?>' class='textadd'>
Text Rotator Type
<select name='rotatortype' class='textadd'>
	<option value="<?php echo $webdata[rotatortype]; ?>"><?php echo $webdata[rotatortype]; ?></option>
				<optgroup label="Attention Seekers">
                  <option value="bounce">bounce</option>
                  <option value="flash">flash</option>
                  <option value="pulse">pulse</option>
                  <option value="rubberBand">rubberBand</option>
                  <option value="shake">shake</option>
                  <option value="swing">swing</option>
                  <option value="tada">tada</option>
                  <option value="wobble">wobble</option>
                </optgroup>
                <optgroup label="Bouncing Entrances">
                    <option value="bounceIn">bounceIn</option>
                    <option value="bounceInDown">bounceInDown</option>
                    <option value="bounceInLeft">bounceInLeft</option>
                    <option value="bounceInRight">bounceInRight</option>
                    <option value="bounceInUp">bounceInUp</option>
                </optgroup>
                <optgroup label="Fading Entrances">
                  <option value="fadeIn">fadeIn</option>
                  <option value="fadeInDown">fadeInDown</option>
                  <option value="fadeInDownBig">fadeInDownBig</option>
                  <option value="fadeInLeft">fadeInLeft</option>
                  <option value="fadeInLeftBig">fadeInLeftBig</option>
                  <option value="fadeInRight">fadeInRight</option>
                  <option value="fadeInRightBig">fadeInRightBig</option>
                  <option value="fadeInUp">fadeInUp</option>
                  <option value="fadeInUpBig">fadeInUpBig</option>
                </optgroup>
                <optgroup label="Flipping Entrances">
                  <option value="flip">flip</option>
                  <option value="flipInX">flipInX</option>
                  <option value="flipInY">flipInY</option>
                </optgroup>
                <optgroup label="Rotating Entrances">
                  <option value="rotateIn">rotateIn</option>
                  <option value="rotateInDownLeft">rotateInDownLeft</option>
                  <option value="rotateInDownRight">rotateInDownRight</option>
                  <option value="rotateInUpLeft">rotateInUpLeft</option>
                  <option value="rotateInUpRight">rotateInUpRight</option>
                </optgroup>
                <optgroup label="Zoom Entrances">
                  <option value="zoomIn">zoomIn</option>
                  <option value="zoomInDown">zoomInDown</option>
                  <option value="zoomInLeft">zoomInLeft</option>
                  <option value="zoomInRight">zoomInRight</option>
                  <option value="zoomInUp">zoomInUp</option>
                </optgroup>
                <optgroup label="Others">
                  <option value="lightSpeedIn">lightSpeedIn</option>
                  <option value="rollIn">rollIn</option>
                </optgroup>
</select>
Nomor HP (Pastikan Terhubung Dengan Whatsapp)
<input type='text' name='nomorhp' value='<?php echo $webdata[nomorhp]; ?>' class='textadd'>
Link Lokasi Google Maps
<input type='text' name='maps' value='<?php echo $webdata[maps]; ?>' class='textadd'>
Alamat Kantor
<input type='text' name='office' value='<?php echo $webdata[office]; ?>' class='textadd'>
Facebook URL (Kosongkan Jika Tidak Memiliki)
<input type='text' name='facebook' value='<?php echo $webdata[facebook]; ?>' class='textadd'>
Instagram URL  (Kosongkan Jika Tidak Memiliki)
<input type='text' name='instagram' value='<?php echo $webdata[instagram]; ?>' class='textadd'>
YouTube Channel Url  (Kosongkan Jika Tidak Memiliki)
<input type='text' name='youtube' value='<?php echo $webdata[youtube]; ?>' class='textadd'>
<input type='submit' name='submit' value='Simpan' class='submitsite'>
</form>
