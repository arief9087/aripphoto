<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title:{
		text: "Data Kunjungan"
	},
	axisY:{
		includeZero: false
	},
	axisX:{
		valueFormatString: "DD MMM",
		crosshair: {
			enabled: true,
			snapToDataPoint: true
		}
	},
	data: [{        
		type: "line",  
		xValueFormatString: "DD MMM, YYYY",     
		dataPoints: [
			{ x: new Date(2017, 0, 1), y: 650 },
			{ x: new Date(2017, 0, 2), y: 700 },
			{ x: new Date(2017, 0, 3), y: 710 },
			{ x: new Date(2017, 0, 4), y: 658 },
			{ x: new Date(2017, 0, 5), y: 734 },
			{ x: new Date(2017, 0, 6), y: 963 },
			{ x: new Date(2017, 0, 7), y: 847 },
			{ x: new Date(2017, 0, 8), y: 853 },
			{ x: new Date(2017, 0, 9), y: 869 },
			{ x: new Date(2017, 0, 10), y: 943 },
			{ x: new Date(2017, 0, 11), y: 970 },
			{ x: new Date(2017, 0, 12), y: 869 },
			{ x: new Date(2017, 0, 13), y: 890 },
			{ x: new Date(2017, 0, 14), y: 930 }
		]
	}]
});
chart.render();

}
</script>
<div id="chartContainer" style="height: 300px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
