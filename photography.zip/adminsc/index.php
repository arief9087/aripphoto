<?php
if(!$_SESSION['admin']){
	header("location:./landing?location=adminarea/authentication/&bb");
}
?>
<div class='adminhead'>
<?php echo $webinfo[webname]; ?>
</div>
<div class='adminmenu'>
	<a href='landing?location=adminarea/&adminpage=home/'><button style='background:brown'>Home</button></a>
	<a href='landing?location=adminarea/&adminpage=site-settings/'><button style='background:orange'>Site Settings</button></a>
	<a href='landing?location=adminarea/&adminpage=galery/'><button style='background:green'>Galeri</button></a>
	<a href='landing?location=adminarea/&adminpage=admin-settings/'><button style='background:blue'>Admin Settings</button></a>
	<a href='landing?location=adminarea/&adminpage=logout/'><button style='background:tomato;float:right'>Log Out</button></a>
</div>
<div class='line'></div>
<div id='adminpage'>
	<?php
	$adminloc = $_GET['adminpage'];
	if(!$adminloc){
		header("location:landing?location=adminarea/&adminpage=home/");
	}else
	if($adminloc == "home/"){
		include "adminhome.php";
	}else
	if($adminloc == "galery/kategori/"){
		include "galeri-kat.php";
	}else
	if($adminloc == "site-settings/"){
		include "site-settings.php";
	}else
	if($adminloc == "galery/"){
		include "galery.php";
	}else
	if($adminloc == "admin-settings/"){
		include "admin-settings.php";
	}else{
		header("location:landing?location=adminarea/&adminpage=home/");
	}
	?>
</div>
