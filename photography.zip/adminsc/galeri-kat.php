<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
$idkat = rand(11111,99999);
$namakat = $_POST['katname'];
$komntar = $_POST['komntar'];
if(isset($_POST["submit"])){
$target_file = basename($_FILES["m_upload"]["name"]);
$file_tmp = $_FILES["m_upload"]["tmp_name"];	
$ekstensi_diperbolehkan	= array('png','jpg','jpeg');
$x = explode('.', $target_file);
$ekstensi = strtolower(end($x));
if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){			
$renamefile = md5("$target_file $waktulokal");
$newfilename = "$renamefile.$ekstensi";
if(move_uploaded_file($file_tmp, 'img/demo/'.$newfilename)){

	$tambah = mysql_query("INSERT INTO kategorigambar(id,name,komntar,imgcover)values('$idkat','$namakat','$komntar','$newfilename')");
	if($tambah){
		echo "<script>swal('Berhasil!', 'Kategori Ditambahkan!', 'success');</script>";
	}else{
		echo "<script>swal('Kesalahan!', 'Gagal Menambahkan Kategori!', 'error');</script>";
	}
	
}else{
echo "<script>swal('Kesalahan!', 'Gagal Mengupload Gambar!', 'error');</script>";
}
}else{
echo "<script>swal('Kesalahan!', 'Ekstensi File Tidak Diperbolehkan!', 'error');</script>";
}
}
?>
<form action="" method="post" enctype="multipart/form-data">
	Nama Kategori
	<input type='text' name='katname' placeholder='Masukan Nama' class='textadd'>
	Gambar Cover
	<input type="file" name="m_upload" class="textadd">
	Baris Komentar: (maksimal 50 karakter)
	<textarea name='komntar' class='textadd'></textarea>
	<input type='submit' name='submit' value='Buat' class='submitsite' style='background:green'>
</form>

<hr/>

<table style="width:100%;align:center" align="center">
  
  <tr style='background:black;padding:5px;color:white;border:none;'>
    <th>Cover</th>
    <th>Id Kategori</th>
    <th>Name</th>
    <th>Aksi</th>
  </tr>
  
<?php
$no=1;
$que=mysql_query("SELECT * FROM kategorigambar");
while($row=mysql_fetch_array($que)){
if(($no % 2)==0){
	echo "<tr style='background:#D8D8D8;padding:5px;border:none;'><td><img src='img/demo/$row[imgcover]' name='$webinfo[webname]' title='$webinfo[webname]' width='75px'></td><td>$row[id]</td><td>$row[name]</td><td>Hapus</td></tr>";
}else{
	echo "<tr style='background:#E7E7E7;padding:5px;border:none;'><td><img src='img/demo/$row[imgcover]' name='$webinfo[webname]' title='$webinfo[webname]' width='75px'></td><td>$row[id]</td><td>$row[name]</td><td>Hapus</td></tr>";
}
$no++;
}
?>

</table>
<br/><br/><br/>
