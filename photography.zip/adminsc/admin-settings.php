<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<?php
$passold = $_POST["old"];
$passnew = $_POST["new"];
$passcon = $_POST["confirm"];
if(!$_POST['submit']){
	echo "";
}else{
	$hash = base64_encode("$passold");
	$hashed = md5("$passold $hash");
	$login = mysql_query("SELECT * FROM admin WHERE password='$hashed'");
	if(mysql_num_rows($login) <> 0){
		if(!$passnew||!$passold){
			echo "<script>swal('Kesalahan!', 'Password Baru Kosong!', 'error');</script>";
		}else{
			if($passnew == "$passcon"){
				$baru = base64_encode("$passnew");
				$newpass = md5("$passnew $baru");
				$ganti = mysql_query("UPDATE admin SET password='$newpass' WHERE password='$hashed'");
				if($ganti){
					echo "<script>swal('Berhasil!', 'Password Telah Diganti!', 'success');</script>";
				}else{
					echo "<script>swal('Kesalahan!', 'Gagal Mengubah Password!', 'error');</script>";
				}
			}else{
				echo "<script>swal('Kesalahan!', 'Password Tidak Sama!', 'error');</script>";
			}
		}
	}else{
		echo "<script>swal('Kesalahan!', 'Password Salah!', 'error');</script>";
	}
}
?>
<form method='post' action=''>
Password Lama
<input type='text' name='old' value='' class='textadd'>
Password Baru
<input type='text' name='new' value='' class='textadd'>
Konfirmasi Password
<input type='text' name='confirm' value='' class='textadd'>
<input type='submit' name='submit' value='Simpan' class='submitsite'>
</form>
