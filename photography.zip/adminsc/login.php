<div class='indexhead'>
	<div class='text'>
		<img src='img/arvix.png'>
		<div class='title'>ARVIX STUDIO</div>
       <div class='login'>
		   <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
			<?php
			$securitykey = $_POST['password'];
			$hash = base64_encode("$securitykey");
			$hashed = md5("$securitykey $hash");
			if(!$_POST['submit']){
				echo '';
			}else
			if(!preg_match("/^[a-zA-Z0-9]*$/",$securitykey)) {
				echo '<script>swal("Kesalahan!", "Tidak Dapat Login!", "error");</script>';
			}else{
			$login = mysql_query("SELECT * FROM admin WHERE password='$hashed'");
				if(mysql_num_rows($login) <> 0){
					session_start();
					$_SESSION['admin'] = $hashed;
					header("location:./landing?location=adminarea/");
				}else{
					echo "<script>swal('Kesalahan!', 'Password Salah!', 'error');</script>";
				}
			}
			?>
		  <form method='post' aciton=''>
			Security Code:
			<input type='password' name='password' id='password' placeholder='*********'>
			<input type='submit' name='submit' id='submit' value='Go To Admin Area'>
		</form>
       </div>
        <br/><br/><br/><br/><br/><br/><br/>
	</div>
</div>

<script src="//code.jquery.com/jquery-1.10.2.js"></script>
<script src="<?php echo $weburl;?>/js/jquery.backstretch.min.js"></script>
<script type="text/javascript">
	$.backstretch(
	[
		"<?php echo $weburl;?>/img/background/1.jpg",
		"<?php echo $weburl;?>/img/background/3.jpg",
		"<?php echo $weburl;?>/img/background/2.jpg"
	], 
	{
		duration: 1200, 
		fade: 600
	});
</script>

