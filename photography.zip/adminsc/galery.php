<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php
$fotoid = $_GET['delid'];
if(!$fotoid){
	echo "";
}else{
	$cekfoto = mysql_query("SELECT * FROM galeri WHERE id='$fotoid'");
	if(mysql_num_rows($cekfoto) == "0"){
		echo "<script>swal('Kesalahan!', 'Gambar tidak tersedia!', 'error');</script>";
	}else{
		$hapusfoto = mysql_query("DELETE FROM galeri WHERE id='$fotoid'");
		if($hapusfoto){
			echo "<script>swal('Berhasil!', 'Gambar Terhapus!', 'success');</script>";
		}else{
			echo "<script>swal('Kesalahan!', 'Gagal Menghapus Gambar!', 'error');</script>";
		}
	}
}
?>
<?php
	$post=$_POST["submit"];
	if(isset($_POST["submit"])){
	$katimg = $_POST['kategori'];
	$target_file = basename($_FILES["m_upload"]["name"]);
	$file_tmp = $_FILES["m_upload"]["tmp_name"];
	
			$ekstensi_diperbolehkan	= array('png','jpg','jpeg');
			$x = explode('.', $target_file);
			$ekstensi = strtolower(end($x));
			if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
			
			$renamefile = md5("$target_file $waktulokal");
			$newfilename = "$renamefile.$ekstensi";
		if(move_uploaded_file($file_tmp, 'img/demo/'.$newfilename)){
				$query = mysql_query("INSERT INTO `galeri`(urlfoto,kategori) VALUES ('$newfilename','$katimg')");
					if($query){
						echo "<script>swal('Berhasil!', 'Gambar Berhasil di Upload', 'success');</script>";
					}else{
						echo "<script>swal('Kesalahan!', 'Gagal Mengupload Gambar!', 'error');</script>";
					}
		}else{
			echo "<script>swal('Kesalahan!', 'Gagal Mengupload Gambar!', 'error');</script>";
		}
		}else{
			echo "<script>swal('Kesalahan!', 'Ekstensi File Tidak Diperbolehkan!', 'error');</script>";
		}
	}
?>
<form action="" method="post" enctype="multipart/form-data">
	Upload Image
	<input type="file" name="m_upload" class="textadd">
	kategori
	<select name='kategori' class='textadd'>
		<?php
		$que=mysql_query("SELECT * FROM kategorigambar");
		while($row=mysql_fetch_array($que)){
			echo "<option value='$row[id]'>$row[name]</option>";
		}
		?>
	</select>
	<input type='submit' name='submit' value='Upload' class='submitsite' style='background:green'>
</form>
<a href='landing?location=adminarea/&adminpage=galery/kategori/'><button class='submitsite' style='background:orange'>Buat Kategori</button></a>
<hr/>
<table style="width:100%;align:center" align="center">
  
  <tr style='background:black;padding:5px;color:white;border:none;'>
    <th>Gambar</th>
    <th>Id Kategori</th>
    <th>Name Katehori</th>
    <th>Aksi</th>
  </tr>
  
<?php
$no=1;
$que=mysql_query("SELECT * FROM galeri ORDER BY id ASC");
while($row=mysql_fetch_array($que)){
	$datakat = mysql_fetch_array(mysql_query("SELECT * FROM kategorigambar WHERE id='$row[kategori]'"));
if(($no % 2)==0){
	echo "<tr style='background:#D8D8D8;padding:5px;border:none;'><td><img src='img/demo/$row[urlfoto]' name='$webinfo[webname]' title='$webinfo[webname]' width='75px'></td><td>$datakat[id]</td><td>$datakat[name]</td><td>Hapus</td></tr>";
}else{
	echo "<tr style='background:#E7E7E7;padding:5px;border:none;'><td><img src='img/demo/$row[urlfoto]' name='$webinfo[webname]' title='$webinfo[webname]' width='75px'></td><td>$datakat[id]</td><td>$datakat[name]</td><td>Hapus</td></tr>";
}
$no++;
}
?>

</table>
<br/><br/><br/>
