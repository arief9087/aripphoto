<?php
session_start();
error_reporting(0);
@mysql_connect("localhost","root","")or die("MySql Conneciton Error");
mysql_select_db("photography")or die("database not found");


$getwebinfo = mysql_query("SELECT * FROM site WHERE id='1'");
$webinfo = mysql_fetch_array($getwebinfo);

$weburl = $webinfo['url'];
?>
