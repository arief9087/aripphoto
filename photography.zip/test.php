<script src="js/sweetalert2.min.js"></script>
<link rel="stylesheet" href="sweetalert2.min.css">

<script src="js/sweetalert2.js"></script>
<link rel="stylesheet" href="sweetalert2.css">

<script src="js/sweetalert2.all.min.js"></script>
<script src="js/sweetalert2.all.js"></script>

<script>swal({
  title: 'Error!',
  text: 'Do you want to continue',
  type: 'error',
  confirmButtonText: 'Cool'
})</script>
